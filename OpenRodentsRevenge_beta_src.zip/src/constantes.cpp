#include <sstream>
#include "constantes.hpp"

GameVariables gv;

using namespace sf;

GameVariables::GameVariables() : debugMode(false), nbOfCats(3),
    catsCannotMoveNbBeforeDead(DEFAULTNB_OF_CAT), score(0),
    currentTheme(defaultTheme)
{

}

void GameVariables::drawFps(sf::RenderWindow &App)
{
    static bool init = false;
    static Clock refreshClock;
    static String string;
    std::ostringstream oss;
    if (!init || refreshClock.GetElapsedTime() >= 1.f)
    {
        float fps = 1.f / App.GetFrameTime();
        if (fps < 0)
            fps = 0;
        oss << static_cast<int>(fps);
        string.SetText(oss.str());
        if (!init)
            init = true;
        refreshClock.Reset();
    }
    App.Draw(string);
}

std::string GameVariables::nbToText(const int &nb)
{
    std::ostringstream oss;
        oss << nb;
    return oss.str();
}
