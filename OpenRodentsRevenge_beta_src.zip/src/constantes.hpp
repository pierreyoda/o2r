#ifndef CONSTANTES_HPP
#define CONSTANTES_HPP

#include <string>
#include <SFML/Graphics.hpp>

const unsigned int LVL_X =  23;
const unsigned int LVL_Y = 23;
const unsigned int CASE_SIZE = 16;
const unsigned int HUD_HEIGHT = 35;
const unsigned int SCREEN_W = LVL_X * CASE_SIZE;
const unsigned int SCREEN_H = LVL_Y * CASE_SIZE + HUD_HEIGHT;
const float CAT_SPEED = 0.75f;
const unsigned int SCORE_BY_CAT = 10;
const unsigned int DEFAULTNB_OF_CAT = 3;
const std::string defaultTheme = "data/default/";

struct GameVariables
 {
     GameVariables();

    bool debugMode;
    unsigned int nbOfCats, catsCannotMoveNbBeforeDead, score;
    std::string currentTheme;

    static void drawFps(sf::RenderWindow &App);
    static std::string nbToText(const int &nb);
 };

 extern GameVariables gv;

#endif /* CONSTANTES_HPP */
