#include "HudManager.hpp"
#include "../constantes.hpp"
#include "../tools/ImageManager.hpp"

using namespace sf;

const Color HUD_BACKGROUND_COLOR(0, 128, 128);

HudManager::HudManager()
{
    m_renderTarget.Create(gv.SCREEN_W, gv.SCREEN_H);
    m_renderResult.SetImage(m_renderTarget.GetImage());

    createHud();
}

void HudManager::createHud()
{
    Vector2f refPos(0, gv.SCREEN_H-HUD_HEIGHT);
    hudBackground = Shape::Rectangle(refPos, Vector2f(gv.SCREEN_W, gv.SCREEN_H),
                                        HUD_BACKGROUND_COLOR);

    score.SetPosition(refPos);
        score.SetString("Score: " + gv.nbToText(gv.score));
    nbOfCats.SetPosition(gv.SCREEN_W-130.f, refPos.y);
    // Editor
    Vector2f posBlock(refPos);
    Vector2f posWall(gv.SCREEN_W/2-40.f, refPos.y);
    Vector2f posMouse(gv.SCREEN_W-80.f, refPos.y);
    editorBlock.SetPosition(posBlock);
        editorBlock.SetString("1 : ");
    editorWall.SetPosition(posWall);
        editorWall.SetString("2 : ");
    editorMouse.SetPosition(posMouse);
        editorMouse.SetString("M : ");
    // Editor - Images
    static const float gap = 40.f;
    sEditorBlock.SetImage(*gImageManager.getResource("block.png"));
        sEditorBlock.SetPosition(posBlock.x + gap, posBlock.y + gap/3);
    sEditorWall.SetImage(*gImageManager.getResource("wall.png"));
        sEditorWall.SetPosition(posWall.x + gap, posWall.y + gap/3);
    Image &img = *gImageManager.getResource("mouse.png");
    sEditorMouse.SetImage(img);
        sEditorMouse.SetPosition(posMouse.x + gap + 10.f, posMouse.y + gap/3);
        img.CreateMaskFromColor(Color(128, 128, 0));
}

const Sprite &HudManager::drawHud(const unsigned int &catsNb, const bool &inGame)
{
    updateScore();
    updateNbOfCats(catsNb);

    m_renderTarget.Clear(Color(0, 0, 0, 0));
        m_renderTarget.Draw(hudBackground);
        if (inGame)
        {
            m_renderTarget.Draw(score);
            m_renderTarget.Draw(nbOfCats);
        }
        else
        {
            m_renderTarget.Draw(editorBlock);
            m_renderTarget.Draw(editorWall);
            m_renderTarget.Draw(editorMouse);
            m_renderTarget.Draw(sEditorBlock);
            m_renderTarget.Draw(sEditorWall);
            m_renderTarget.Draw(sEditorMouse);
        }

    m_renderTarget.Display();

    return m_renderResult;
}

void HudManager::updateScore()
{
    static unsigned int prevScore = 0;
    if (prevScore != gv.score)
    {
        score.SetString("Score: " + gv.nbToText(gv.score));
        prevScore = gv.score;
    }
}

void HudManager::updateNbOfCats(const unsigned int &catsNb)
{
    static unsigned int prevCatsNb = 0;
    if (prevCatsNb != catsNb)
    {
        nbOfCats.SetString("Cats: " + gv.nbToText(catsNb));
        prevCatsNb = catsNb;
    }
}

void HudManager::drawFps(RenderTarget &target, const float &fpsCount)
{
    static bool init = false, resetpos = true;;
    static Clock refreshClock;
    static Text text;
    if (!init || refreshClock.GetElapsedTime() >= 1.f)
    {
        if (!init)
        {
            text.SetString("60");
            text.SetCharacterSize(20);
            init = true;
        }
        float fps = 1.f / fpsCount;
        if (fps < 0)
            fps = 0;
        else if (fps >= 100)
            resetpos = true;
        text.SetString(gv.nbToText(static_cast<int>(fps)));
        if (resetpos)
        {
            Vector2f size(text.GetRect().GetSize());
            text.SetPosition(gv.SCREEN_W-size.x, gv.SCREEN_H-size.y);
            resetpos = false;
        }
        refreshClock.Reset();
    }
    target.Draw(text);
}

