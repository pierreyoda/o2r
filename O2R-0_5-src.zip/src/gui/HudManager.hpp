#ifndef HUDMANAGER_HPP
#define HUDMANAGER_HPP

#include <SFML/Graphics.hpp>

class HudManager
{
    public:
        HudManager();

        void createHud();

        const sf::Sprite &drawHud(const unsigned int &catsNb,
                                  const bool &inGame = true);
        static void drawFps(sf::RenderTarget &target, const float &fpsCount);

    private:
        void updateScore();
        void updateNbOfCats(const unsigned int &catsNb);

        sf::RenderImage m_renderTarget;
        sf::Sprite m_renderResult;
        sf::Text score, nbOfCats, editorBlock, editorWall, editorMouse;
        sf::Sprite sEditorBlock, sEditorWall, sEditorMouse;
        sf::Shape hudBackground;
};

#endif /* HUDMANAGER_HPP */
