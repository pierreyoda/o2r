#ifndef CONSTANTES_HPP
#define CONSTANTES_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include "tools/ProgramOptions.hpp"

#define USE_WXGUI 0

const unsigned int DLVL_X =  23;
const unsigned int DLVL_Y = 23;
const unsigned int CASE_SIZE = 16;
const unsigned int HUD_HEIGHT = 35;
const unsigned int DSCREEN_W = DLVL_X * CASE_SIZE;
const unsigned int DSCREEN_H = DLVL_Y * CASE_SIZE + HUD_HEIGHT;
const unsigned int SCORE_BY_CAT = 10;
const unsigned int DEFAULTNB_OF_CAT = 3;
const float CAT_SPEED = 0.75f;
const bool ORIGIN_AT_CENTER = false;
const bool USE_WINDOWGUI = USE_WXGUI;
const std::string defaultTheme = "data/base/";

struct GameVariables
 {
     GameVariables();

    bool debugMode, sizeChanged;
    unsigned int LVL_X, LVL_Y, SCREEN_W, SCREEN_H;
    unsigned int nbOfCats, catsCannotMoveNbBeforeDead, score;
    const std::string gameVersion, windowTitle;
    ProgramOptions options;

    void resizeGame();
    static void drawFps(sf::RenderWindow &App);
    static int textToNb(const std::string &text);
    static std::string nbToText(const int &nb);
 };

 extern GameVariables gv;

#endif /* CONSTANTES_HPP */
