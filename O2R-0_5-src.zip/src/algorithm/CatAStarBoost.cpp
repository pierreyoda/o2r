#include <cmath>
#include <boost/graph/astar_search.hpp>
#include <boost/graph/adjacency_list.hpp>
#include "CatAStarBoost.hpp"

CatAStarBoost::CatAStarBoost(const Level &lvl) : level(lvl)
{

}

CatAStarBoost::~CatAStarBoost()
{

}
