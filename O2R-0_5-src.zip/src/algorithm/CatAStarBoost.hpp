#ifndef CATASTARBOOST_HPP
#define CATASTARBOOST_HPP

#include <list>
#include "../Level.hpp"

class CatAStarBoost
{
    public:
        CatAStarBoost(const Level &lvl);
        ~CatAStarBoost();

    private:
        const Level &level;
};

#endif /* CATASTARBOOST_HPP */
