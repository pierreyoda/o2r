#include <iostream>
#include <sstream>
#include "Engine.hpp"
#include "constantes.hpp"
#include "LevelFileInterpreter.hpp"
#include "gui/TextBox.hpp"
#include "gui/Button.hpp"

using namespace sf;

// TODO (Pierre-Yves#2#): [GENERAL]Ajouter zoom automatique pour niveaux de tailles non standards...
Engine::Engine(sf::RenderWindow &window, const bool &vsync,
    const unsigned int &fpslimit) : App(window),
    mouse(level, cats), currentLevel(""), gameView(),
    gameViewZoomFactor(10)
{
    gameView.SetSize(gv.SCREEN_W, gv.SCREEN_H);
    gameView.SetCenter(gv.SCREEN_W/2, gv.SCREEN_H/2);

    App.UseVerticalSync(vsync);
    App.SetFramerateLimit(fpslimit);
    App.SetIcon(16, 16, gImageManager.getResource("icon.png")
                ->GetPixelsPtr());
}

Engine::~Engine()
{
    cats.clear();
}

bool Engine::loadLevel(const std::string &filename)
{
    if (filename == "")
        return false;
    if (!LevelFileInterpreter::readLevel(level, filename))
    {
        level.resetLevel();
        return false;
    }
    currentLevel = filename;
    if (gv.sizeChanged)
    {
        hud.createHud();
        resizeGameView();
        gv.sizeChanged = false;
    }
    return true;
}

void Engine::resizeGameView()
{

}

void Engine::initializeGame(const bool &newlvl)
{
    std::cout << "Initializing game\n";
    gv.score = 0;
    cats.clear();
    if (!newlvl)
        loadLevel("data/1.txt");
    level.randomWalls();
    mouse.setPosition(level.getMouseStartPos());
    for (unsigned int i = 0; i < gv.nbOfCats; i++)
    {
        Cat cat;
        cat.placeCat(level, cats);
        cats.push_back(cat);
    }
}

void Engine::drawFps()
{
    if (gv.debugMode)
        hud.drawFps(App, App.GetFrameTime());
}

void Engine::run()
{
    const float middleX = App.GetWidth()/2.f, middleY = App.GetHeight()/2.f;
    std::vector<Button> buttons;
    buttons.push_back(Button("Play Game!", Vector2f(middleX-125, middleY-150),
                      Vector2f(middleX+125, middleY-50)));
    buttons.push_back(Button("Create Level", Vector2f(middleX-125, middleY-25),
                        Vector2f(middleX+125, middleY+80)));
    buttons.push_back(Button("Quit", Vector2f(middleX-125, middleY+90),
                        Vector2f(middleX+125, middleY*2-5)));

    static const Input &Input = App.GetInput();
    while (App.IsOpened())
    {
        Vector2f mousePos(Input.GetMouseX(), Input.GetMouseY());
        Event Event;
        while (App.GetEvent(Event))
        {
            if (Event.Type == Event::Closed)
                App.Close();
            if (Event.Type == Event::KeyPressed)
            {
                if (Event.Key.Code == Key::Escape)
                    App.Close();
                if (Event.Key.Code == Key::F12)
                    gv.debugMode = !gv.debugMode;
            }
            if (Event.Type == Event::MouseMoved)
            {
                for (unsigned int i = 0; i < buttons.size(); i++)
                {
                    if (buttons[i].isMouseOver(mousePos))
                        buttons[i].setBorderWidth(12);
                    else
                        buttons[i].setBorderWidth(8);
                }
            }
            if (Event.Type == Event::MouseButtonReleased)
            {
                if (buttons[0].isMouseOver(mousePos))
                    runGame();
                else if (buttons[1].isMouseOver(mousePos))
                    runEditor();
                else if (buttons[2].isMouseOver(mousePos))
                    App.Close();
                App.SetView(App.GetDefaultView());
            }
        }

        App.Clear(Color(0, 128, 0));

        for (unsigned int i = 0; i < buttons.size(); i++)
        {
            App.Draw(buttons[i].getBorder());
            App.Draw(buttons[i].getText());
        }
        drawFps();

        App.Display();
    }
}

void Engine::runGame()
{
    bool astar = false;
    std::cout << "Launching game...\n";
    if (!loadLevel(currentLevel))
        loadLevel("data/1.txt");
    initializeGame(true);
    //App.SetView(gameView);
    while (App.IsOpened())
    {
        Event Event;
        while (App.GetEvent(Event))
        {
            if (Event.Type == Event::Closed)
                App.Close();
            if (Event.Type == Event::KeyPressed)
            {
                if (!USE_WINDOWGUI && Event.Key.Code == Key::Escape)
                {
                    if (menuGame())
                        return;
                    App.SetView(gameView);
                }
                if (Event.Key.Code == Key::F12)
                    gv.debugMode = !gv.debugMode;
                if (Event.Key.Code == Key::A)
                    astar = !astar;
                if (cats.size() >= 1 && Event.Key.Code == Key::D)
                    cats.begin()->die();
                if (cats.size() >= 1 && cats.begin()->isAlive() && Event.Key.Code == Key::K)
                    Cat::killCat(cats.begin()->pos(), cats);
                if (Event.Key.Code == Key::Up)
                    mouse.move(UP);
                else if (Event.Key.Code == Key::Down)
                    mouse.move(DOWN);
                if (Event.Key.Code == Key::Left)
                    mouse.move(LEFT);
                else if (Event.Key.Code == Key::Right)
                    mouse.move(RIGHT);
            }
        }

        updateCats(astar);

        App.Clear();

        App.Draw(level.getRenderResult());
        for (unsigned int i = 0; i < cats.size(); i++)
            App.Draw(cats[i].sprite());
        App.Draw(mouse.sprite());
        App.Draw(hud.drawHud(cats.size(), true));
            drawFps();

        App.Display();
    }
}

void Engine::updateCats(const bool &astar)
{
    for (unsigned int i = 0; i < cats.size(); i++)
    {
        Cat &cat = cats[i];
        if (cat.isAlive())
        {
            if (cat.moveCat(level, mouse.pos(), cats, !astar) && !mouse.dead())
                mouse.die();
            if (cat.cannotMoveNb() > 0)
                cat.setImage(*gImageManager.getResource("cat_awaiting.png"));
            else
                cat.setImage(*gImageManager.getResource("cat.png"));
            if (cat.cannotMoveNb() >= gv.catsCannotMoveNbBeforeDead)
                cat.die();
        }
    }
}

bool Engine::menuGame()
{
    const float middleX = App.GetWidth()/2.f, middleY = App.GetHeight()/2.f;
    bool writing = false;
    TextBox textBox(0, currentLevel);
    std::vector<Button> buttons;
    buttons.push_back(Button("Resume", Vector2f(middleX-175, middleY-150),
                             Vector2f(middleX-10, middleY-50)));
    buttons.push_back(Button("Exit", Vector2f(middleX+10, middleY-150),
                             Vector2f(middleX+175, middleY-50)));
    buttons.push_back(Button("Open Level", Vector2f(middleX-175, middleY+75),
                             Vector2f(middleX+175, middleY+175)));

    App.SetView(App.GetDefaultView());
    static const Input &Input = App.GetInput();
    while (App.IsOpened())
    {
        Vector2f mousePos(Input.GetMouseX(), Input.GetMouseY());
        Event Event;
        while (App.GetEvent(Event))
        {
            if (Event.Type == Event::Closed)
            {
                App.Close();
                return true;
            }
            if (Event.Type == Event::KeyPressed)
            {
                if (Event.Key.Code == Key::Escape)
                    return false;
                if (Event.Key.Code == Key::Delete)
                    textBox.clearText();
                if (writing && Event.Key.Code == Key::Return)
                {
                    if (loadLevel(textBox.getString()))
                    {
                        writing = false;
                        initializeGame(true);
                        return false;
                    }
                }
            }
            if (writing && Event.Type == Event::TextEntered)
                textBox.onTextEntered(Event.Text.Unicode);
            if (Event.Type == Event::MouseMoved)
            {
                for (unsigned int i = 0; i < buttons.size(); i++)
                {
                    if (buttons[i].isMouseOver(mousePos))
                        buttons[i].setBorderWidth(12);
                    else
                        buttons[i].setBorderWidth(8);
                }
            }
            if (Event.Type == Event::MouseButtonReleased)
            {
                if (buttons[0].isMouseOver(mousePos))
                    return false;
                else if (buttons[1].isMouseOver(mousePos))
                    return true;
                else if (buttons[2].isMouseOver(mousePos))
                    writing = true;
            }
        }

        App.Clear(Color(0, 128, 0));
            for (unsigned int i = 0; i < buttons.size(); i++)
            {
                App.Draw(buttons[i].getBorder());
                App.Draw(buttons[i].getText());
            }
            if (writing)
                App.Draw(textBox.getText());
            drawFps();

        App.Display();
    }
    return true;
}

void Engine::runEditor()
{
    std::cout << "Launching level editor...\n";
    if (!loadLevel(currentLevel))
        loadLevel("data/1.txt");
    mouse.setPosition(level.getMouseStartPos());
    CASETYPE casetype = BLOCK;
    App.SetView(gameView);
    const Input &Input = App.GetInput();
    while (App.IsOpened())
    {
        Vector2f mousepos = App.ConvertCoords(App.GetInput().GetMouseX(),
                                              App.GetInput().GetMouseY());

        Event Event;
        while (App.GetEvent(Event))
        {
            if (Event.Type == Event::Closed)
                App.Close();
            if (Event.Type == Event::KeyPressed)
            {
                if (!USE_WINDOWGUI && Event.Key.Code == Key::Escape)
                {
                    if (menuEditor())
                        return;
                    App.SetView(gameView);
                }
                if (Event.Key.Code == Key::F12)
                    gv.debugMode = !gv.debugMode;
                if (Event.Key.Code == Key::M)
                    placeMouse(mousepos);
                if (Event.Key.Code == Key::Num1 || Event.Key.Code == Key::Numpad1)
                    casetype = BLOCK;
                if (Event.Key.Code == Key::Num2 || Event.Key.Code == Key::Numpad2)
                    casetype = WALL;
            }
        }

        if (mousepos.x < gv.SCREEN_W && mousepos.y < gv.SCREEN_H-HUD_HEIGHT)
        {
            if (Input.IsMouseButtonDown(sf::Mouse::Left))
                placeCaseType(mousepos, casetype);
            else if (Input.IsMouseButtonDown(sf::Mouse::Right))
                clearCase(mousepos);
        }

        App.Clear();

        App.Draw(level.getRenderResult());
        App.Draw(mouse.sprite());
        App.Draw(hud.drawHud(cats.size(), false));
            drawFps();

        App.Display();
    }
}

// TODO (Pierre-Yves#3#): [LEVEL-EDITOR] Ajouter gestion automatique du nombre de chats et de murs al�atoires dans le niveau (menu? ==> wxWidget? / Qt?)
bool Engine::menuEditor()
{
    bool writing = false, save = false;
    TextBox textBox(0, currentLevel);
    std::vector<Button> buttons;
        const float middleX = App.GetWidth()/2.f, middleY = App.GetHeight()/2.f;
    buttons.push_back(Button("Resume", Vector2f(middleX-175, middleY-150),
                             Vector2f(middleX-10, middleY-50)));
    buttons.push_back(Button("Exit", Vector2f(middleX+10, middleY-150),
                             Vector2f(middleX+175, middleY-50)));
    buttons.push_back(Button("Save Level", Vector2f(middleX-175, middleY-25),
                             Vector2f(middleX+175, middleY+65)));
    buttons.push_back(Button("Open Level", Vector2f(middleX-175, middleY+75),
                             Vector2f(middleX+175, middleY+175)));

    App.SetView(App.GetDefaultView());
    static const Input &Input = App.GetInput();
    while (App.IsOpened())
    {
        Vector2f mousePos(Input.GetMouseX(), Input.GetMouseY());
        Event Event;
        while (App.GetEvent(Event))
        {
            if (Event.Type == Event::Closed)
            {
                App.Close();
                return true;
            }
            if (Event.Type == Event::KeyPressed)
            {
                if (Event.Key.Code == Key::Escape)
                    return false;
                if (Event.Key.Code == Key::Delete)
                    textBox.clearText();
                if (writing && Event.Key.Code == Key::Return)
                {
                    if (save && LevelFileInterpreter::writeLevel(level, textBox.getText().GetString()))
                    {
                        currentLevel = textBox.getText().GetString();
                        writing = save = false;
                        return false;
                    }
                    else
                    {
                        loadLevel(textBox.getText().GetString());
                        mouse.setPosition(level.getMouseStartPos());
                        writing = false;
                        return false;
                    }
                }
            }
            else if (writing && Event.Type == Event::TextEntered)
            {
                textBox.onTextEntered(Event.Text.Unicode);
            }
            if (Event.Type == Event::MouseMoved)
            {
                for (unsigned int i = 0; i < buttons.size(); i++)
                {
                    if (buttons[i].isMouseOver(mousePos))
                        buttons[i].setBorderWidth(12);
                    else
                        buttons[i].setBorderWidth(8);
                }
            }
            if (Event.Type == Event::MouseButtonReleased)
            {
                if (buttons[0].isMouseOver(mousePos))
                    return false;
                else if (buttons[1].isMouseOver(mousePos))
                    return true;
                else if (buttons[2].isMouseOver(mousePos))
                    writing = save = true;
                else if (buttons[3].isMouseOver(mousePos))
                    writing = true;
            }
        }

        App.Clear(Color(0, 128, 0));
            for (unsigned int i = 0; i < buttons.size(); i++)
            {
                App.Draw(buttons[i].getBorder());
                App.Draw(buttons[i].getText());
            }
            if (writing)
                App.Draw(textBox.getText());
            drawFps();
        App.Display();
    }
    return true;
}

void Engine::clearCase(const Vector2f &mousepos)
{
    level.setCaseType(pixelToCase(mousepos), NOTHING);
}

void Engine::placeCaseType(const Vector2f &mousepos, const CASETYPE &type)
{
    Vector2i pos = pixelToCase(mousepos);
    if (pos != level.getMouseStartPos())
        level.setCaseType(pos, type);
}

void Engine::placeMouse(const Vector2f &mousepos)
{
    Vector2i pos = pixelToCase(mousepos);
    level.setCaseType(pos, NOTHING);
    level.setMouseStartPos(pos);
    mouse.setPosition(pos);
}

Vector2i Engine::pixelToCase(const Vector2f &pos)
{
    unsigned int x = static_cast<unsigned int>(pos.x/CASE_SIZE);
    unsigned int y = static_cast<unsigned int>(pos.y/CASE_SIZE);
    return Vector2i(x, y);
}
