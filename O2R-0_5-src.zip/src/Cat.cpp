#include <list>
#include <iostream>
#include "Cat.hpp"
#include "constantes.hpp"
#include "tools/ImageManager.hpp"

Cat::Cat() : Object(), m_moveClock(), m_cannotMove(0), m_alive(true)
{
    setImage(*gImageManager.getResource("cat.png"));
}

Cat::~Cat()
{
    /*path->clear();
    delete path;*/
}

void Cat::die()
{
    if (!m_alive)
        return;
    m_alive = false;
    setImage(*gImageManager.getResource("cheese.png"));
    gv.score += SCORE_BY_CAT/5;
}

// TODO (Pierre-Yves#1#): [GAMEPLAY] Corriger l'IA des chats (A*)
bool Cat::moveCat(const Level &lvl, const sf::Vector2i &mousePos,
                  const std::vector<Cat> &cats, const bool &random)
{
    static sf::Vector2i prevMousepos = mousePos;
    static bool first = true;

    if (!m_alive || m_moveClock.GetElapsedTime() < CAT_SPEED)
        return false;
    m_moveClock.Reset();

    if (!random)
    {
        if (first || (mousePos != prevMousepos || lvl.hasChanged()))
        {
            path = AStarAlgorithm::pathfinding(m_pos, mousePos, lvl);
            prevMousepos = mousePos;
            first = false;
        }
        if (!path->empty())
        {
            sf::Vector2i npos(*path->begin());
            path->pop_front();
            setPosition(npos);
            m_cannotMove = 0;
            if (npos == mousePos)
                return true;
        }
        else
        {
            ++m_cannotMove;
            return false;
        }
    }
    else
    {
        static const unsigned int tries = 10;
        sf::Vector2i offset(0, 0), temp(m_pos);
        bool ok = false;
        for (unsigned int i = 0; i < tries && !ok; i++)
        {
            offset.x = sf::Randomizer::Random(-1, 1),
            offset.y = sf::Randomizer::Random(-1, 1);
            temp = m_pos + offset;
            if (!Cat::outOfScreen(temp) && (lvl.getCaseType(temp) == NOTHING
                    /*&& temp != mousePos */&& !catOnTheWay(temp, cats)))
                ok = true;
        }
        if (!ok)
        {
            ++m_cannotMove;
            return false;
        }
        setPosition(temp);
        if (temp == mousePos)
            return true;
        m_cannotMove = 0;
    }
    return false;
}

void Cat::placeCat(const Level &lvl, const std::vector<Cat> &cats)
{
    bool done = false;
    sf::Vector2i pos;
    const unsigned int nbOfFreeCases = lvl.nbOfCasetype(NOTHING);
    for (unsigned int i = 0; i < nbOfFreeCases && !done; i++)
    {
        pos.x = sf::Randomizer::Random(0, gv.LVL_X-1),
        pos.y = sf::Randomizer::Random(0, gv.LVL_Y-1);
        bool ok = !catOnTheWay(pos, cats);
        if (ok && lvl.getCaseType(pos) == NOTHING && lvl.getMouseStartPos() != pos)
            done = true;
    }
    setPosition(pos);
}

void Cat::killCat(const sf::Vector2i &catpos, std::vector<Cat> &cats)
{
    static std::vector<Cat>::iterator iter = cats.begin();
    for (iter = cats.begin(); iter != cats.end(); iter++)
    {
        if (iter->pos() == catpos)
        {
            cats.erase(iter);
            break;
        }
    }
}

bool Cat::catOnTheWay(const sf::Vector2i &pos, const std::vector<Cat> &cats,
                      const bool &excludeDeadCats)
{
    for (unsigned int i = 0; i < cats.size(); i++)
    {
        if (pos == cats[i].pos())
        {
            if (excludeDeadCats && !cats[i].isAlive())
                return false;
            return true;
        }
    }
    return false;
}
