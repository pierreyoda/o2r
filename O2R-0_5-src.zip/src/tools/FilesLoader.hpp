#ifndef FILESLOADER_HPP
#define FILESLOADER_HPP

#include <vector>
#include <string>
#include <boost/filesystem.hpp>

typedef std::vector<std::string> fileList;

class FilesLoader
{
    public:
        FilesLoader() { }

        static bool loadModules(const std::vector<std::string> &modules);

    private:
        static bool loadFiles(const fileList &files, const std::string &dir,
                              const bool checkIfAlreadyLoaded = true);
        static bool findDefinedFiles(fileList &files, const std::string &imgdir);
        static bool findPresentFiles(fileList &files, const std::string &imgdir);
        inline static bool loadFile(const std::string &filepath);
};

#endif /* FILESLOADER_HPP */
